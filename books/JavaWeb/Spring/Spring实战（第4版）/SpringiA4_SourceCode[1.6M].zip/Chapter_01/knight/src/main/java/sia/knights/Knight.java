package sia.knights;

public interface Knight {

  void embarkOnQuest();

}
