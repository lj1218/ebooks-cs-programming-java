spring-data-mongo-samples
=========================
The project is not intended to be built into a deployable JAR file,
but instead includes a test case that demonstrates Spring Data Mongo.
You may run this test case with 'mvn test' or import the project into
your IDE and run the test there.

Note that you'll need mongod running on localhost listening on port
27017 for the test to pass.
